# Day 3 시작 자료

1. 압축을 풀면 생기는 `day03-assets` 폴더 안에서 시작합니다.
2. 먼저 `launch-kit/index.html`을 열고 위쪽 버튼을 모두 눌러 완성 방향을 봅니다.
3. 기본 추천은 `briefs/home-reset-brief.txt`와 `images/home-reset-editorial.png`입니다.
4. 다른 사례는 `briefs/second-career-brief.txt`와 짝이 맞는 사진을 씁니다.
5. `screenshots/02_design_workspace_map.svg`는 실제 캡처가 아닌 버튼 위치 설명도입니다.
6. Claude Desktop의 **디자인 → 새 프로젝트**로 들어갑니다.
7. 선택한 브리프·사진·`brand-style.txt`를 첨부합니다.
8. 커버 3안을 먼저 만들고 하나를 직접 고릅니다.
9. 선택한 스타일로 카드뉴스 7장과 9:16 스토리 1장을 만듭니다.
10. 제목·강조색·사진 크롭을 하나씩 선택 수정합니다.
11. 계정에 실제로 보이는 내보내기 형식 또는 화면 캡처로 저장합니다.

다른 사람의 게시물을 그대로 복제하지 않습니다. 제공 사진은 수업을 위해 만든 생성 이미지입니다.
